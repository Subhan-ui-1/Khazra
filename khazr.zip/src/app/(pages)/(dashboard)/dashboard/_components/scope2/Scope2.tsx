import React from 'react'

const Scope = () => {
  return (
    <div>
      somethikjmju else
    </div>
  )
}

export default Scope
