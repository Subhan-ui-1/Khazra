import React from 'react'

const BillingTab = () => {
    return (
        <div>
        
        </div>
    )
}

export default BillingTab
