import React from 'react'

const TeamTab = () => {
    return (
        <div>
        
        </div>
    )
}

export default TeamTab
