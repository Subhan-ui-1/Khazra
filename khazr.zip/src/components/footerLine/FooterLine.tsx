import React from 'react'

const FooterLine = () => {
    return (
        <div>
        
        </div>
    )
}

export default FooterLine
